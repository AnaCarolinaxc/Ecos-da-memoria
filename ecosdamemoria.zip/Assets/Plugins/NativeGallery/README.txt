= Native Gallery for Android & iOS (v1.9.2) =

Documentation: https://github.com/yasirkula/UnityNativeGallery
FAQ: https://github.com/yasirkula/UnityNativeGallery#faq
Example code: https://github.com/yasirkula/UnityNativeGallery#example-code
E-mail: yasirkula@gmail.com